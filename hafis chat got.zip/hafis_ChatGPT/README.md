# Using Tutorial : https://termux.xyz/how-to-build-a-whatsapp-chatbot-with-chatgpt-in-termux/

  <p>&nbsp;</p><p><br /></p><p><br /></p><p><br /></p>
  <p>&nbsp;</p><p><br /></p><p><br /></p>
  
  
<h1 align="center">Whatsapp GhatGPT AI - OnlineHacking</h1>
<p align="center">
  Wahatapp AI Bot For Termux
</p>
<p align="center">
<a href="https://termux.xyz/how-to-build-a-whatsapp-chatbot-with-chatgpt-in-termux/"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>

</p>


<p align="center">
    <img src="https://img.shields.io/badge/Version-1.0-blue?style=for-the-badge&color=blue">
     <img src="https://img.shields.io/github/stars/OnlineHacKing/Whatsapp-ChatGPT?style=for-the-badge&color=magenta">
  <img src="https://img.shields.io/github/forks/OnlineHacKing/Whatsapp-ChatGPT?color=cyan&style=for-the-badge&color=purple">
  <img src="https://img.shields.io/github/issues/OnlineHacKing/Whatsapp-ChatGPT?color=red&style=for-the-badge">
    <img src="https://img.shields.io/github/license/OnlineHacKing/Whatsapp-ChatGPT?style=for-the-badge&color=blue">
<br>
    <img src="https://img.shields.io/badge/Author-SUMAN-green?style=flat-square">
    <img src="https://img.shields.io/badge/Open%20Source-Yes-orange?style=flat-square">
    <img src="https://img.shields.io/badge/Maintained-No-cyan?style=flat-square">
    <img src="https://img.shields.io/badge/Written%20In-Shell-blue?style=flat-square">
</p>

<p align="center">
<a href="https://termux.xyz/how-to-build-a-whatsapp-chatbot-with-chatgpt-in-termux/"><img title="Made in INDIA" src="https://img.shields.io/badge/Tool-Whatsapp-ChatGPT-green.svg"></a>
<a href="https://termux.xyz/how-to-build-a-whatsapp-chatbot-with-chatgpt-in-termux/"><img title="Version" src="https://img.shields.io/badge/Version-1.1-green.svg?style=flat-square"></a>
<a href="https://termux.xyz/how-to-build-a-whatsapp-chatbot-with-chatgpt-in-termux/"><img title="Maintainence" src="https://img.shields.io/badge/Admin-SUMAN-green.svg"></a>
</p>

##

<h3><p align="center">Disclaimer</p></h3>

<i>Any actions and or activities related to <b>FreeFire-Phishing</b> is solely your responsibility. The misuse of this toolkit can result in <b>criminal charges</b> brought against the persons in question. <b>The contributors will not be held responsible</b> in the event any criminal charges be brought against any individuals misusing this toolkit to break the law.

<b>This toolkit contains materials that can be potentially damaging or dangerous for social media</b>. Refer to the laws in your province/country before accessing, using,or in any other way utilizing this in a wrong way.

<b>This Tool is made for educational purposes only</b>. Do not attempt to violate the law with anything contained here. <b>If this is your intention, then Get the hell out of here</b>!

It only demonstrates "how phishing works". <b>You shall not misuse the information to gain unauthorized access to someones social media</b>. However you may try out this at your own risk.</i>

##

<p align="center">

![unnamed (2)](https://github.com/OnlineHacKing/Whatsapp-ChatGPT/releases/download/1.1/1.jpg)

</p>


## ABOUT TOOL :

This is a source code to build a WhatsApp bot using OpenAI bot and Node.js. The bot is capable of understanding natural language and providing information on various topics. It can be used to answer questions, provide advice, and even have conversations with users. With this source code, you can create a powerful bot that can be used for a variety of purposes. <br>

### AVAILABLE ON :

* Termux App

* Kali Linux

* Parrot OS

* Ubuntu

* Windows

* Arch Linux


### 🎥 WATCH VIDEO 

<p align="center"> <a href="https://www.youtube.com/watch?v=l_lNx4AhvrY&t=14s"><img title="Made in INDIA" width="58%" src="https://www.onlinehacking.in/wp-content/uploads/2021/12/play-.webp"></a>

## ✅ INSTALLATION [ Linux / Termux ] :

 Link: https://termux.xyz/how-to-build-a-whatsapp-chatbot-with-chatgpt-in-termux/


<br>

# How to get OpenAI API?
Visit: https://beta.openai.com/account/api-keys
